from django.apps import AppConfig


class BlogProductConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'blog_product'
