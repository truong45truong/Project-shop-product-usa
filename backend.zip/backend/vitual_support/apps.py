from django.apps import AppConfig


class VitualSupportConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'vitual_support'
