from django.db import models
from login.models import User
# Create your models here.
class LogsSearchProduct(models.Model):
    pass